/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import businessbeans.Sizes;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Joel
 */
@Stateless
public class SizesDAO {

    @Inject
    private DBConnection dbConnection;

    @EJB
    private Sizes size;

    public List<Sizes> getAllSizes() {
        List<Sizes> sizes = new ArrayList<>();
        String sql = "SELECT sizeId, name FROM sizes";

        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Sizes size = new Sizes();
                size.setSizeId(rs.getInt("sizeId"));
                size.setName(rs.getString("name"));
                sizes.add(size);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sizes;
    }

}
