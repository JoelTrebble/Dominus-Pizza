/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import businessbeans.Employee;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Joel
 */
@Stateless
public class EmployeeDAO {

    @Inject
    private DBConnection dbConnection;
    
    
    public Employee validateLogin(String username, String password) {
        String sql = "SELECT username, password FROM employee WHERE username = ? AND password = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Employee employee = new Employee();
                    employee.setUserName(rs.getString("username"));
                    employee.setPassword(rs.getString("password"));
                    return employee;
                }
                //honestly slightly overengineered as there is only one employee currently. It just looks to see if there is a match between key value pairs.
                throw new SecurityException("Invalid username or password");
            }
        } catch (SQLException e) {
            
            throw new RuntimeException("Database error occurred during login validation", e);
        } catch (Exception e) {
            
            throw new RuntimeException("Unexpected error during login validation", e);
        }
    }

}
