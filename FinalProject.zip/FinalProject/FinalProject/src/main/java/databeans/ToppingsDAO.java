/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import businessbeans.Toppings;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Joel
 */
@Stateless
public class ToppingsDAO {

    @Inject
    private DBConnection dbConnection;

    @EJB
    private Toppings topping;

    public List<Toppings> getAllToppings() { //for dashboard
        List<Toppings> toppings = new ArrayList<>();
        String sql = "SELECT toppingId, name, price, isActive FROM toppings";

        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Toppings topping = new Toppings();
                topping.setToppingId(rs.getInt("toppingId"));
                topping.setName(rs.getString("name"));
                topping.setPrice(rs.getString("price"));
                topping.setIsActive(rs.getBoolean("isActive"));
                toppings.add(topping);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return toppings;
    }

    public List<Toppings> getAllToppingsCustomer() { //for customers for which one is active.
        List<Toppings> toppings = new ArrayList<>();
        String sql = "SELECT toppingId, name, price FROM toppings where isActive = 1";

        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Toppings topping = new Toppings();
                topping.setToppingId(rs.getInt("toppingId"));
                topping.setName(rs.getString("name"));
                topping.setPrice(rs.getString("price"));
                toppings.add(topping);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return toppings;
    }

    public void updateToppingStatus(Integer toppingId, boolean isActive) {
        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(
                "UPDATE Toppings SET isActive = ? WHERE toppingId = ?")) {
            stmt.setBoolean(1, isActive);
            stmt.setInt(2, toppingId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            // Handle exception appropriately
            e.printStackTrace();
        }
    }

    public void addTopping(String name, String price) {
        String sql = "INSERT INTO Toppings (name, price, createdate, empAddedBy, isActive) VALUES (?, ?, NOW(), 1, true)";
        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, price);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
