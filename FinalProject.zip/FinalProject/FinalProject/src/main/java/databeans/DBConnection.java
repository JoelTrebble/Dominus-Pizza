/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Singleton;
import jakarta.inject.Inject;
import jakarta.servlet.ServletContext;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Joel
 */

@Singleton
public class DBConnection {
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;
    
    @Inject
    private ServletContext context;
    
    @PostConstruct
    public void init() {
        this.dbUrl = context.getInitParameter("dbUrl");
        this.dbUsername = context.getInitParameter("dbUsername");
        this.dbPassword = context.getInitParameter("dbPassword");
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Failed to load MySQL driver", e);
        }
    }
    
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
    }
}
