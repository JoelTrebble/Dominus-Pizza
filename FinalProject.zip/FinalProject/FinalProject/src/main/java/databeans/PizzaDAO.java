/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import businessbeans.Pizza;
import businessbeans.Toppings;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Joel
 */
@Stateless
public class PizzaDAO {

    @Inject
    private DBConnection dbConnection;

    @EJB
    private Pizza pizza;

    @EJB
    private Toppings topping;

    private static int nextPizzaId = 1;

    public String getSizeName(int sizeId) {
        String sql = "SELECT name FROM sizes WHERE sizeId = ?";
        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, sizeId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("name");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getCrustTypeName(int crustTypeId) {
        String sql = "SELECT name FROM crusttypes WHERE crustTypeId = ?";
        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, crustTypeId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("name");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Toppings getTopping(int toppingId) {
        String sql = "SELECT toppingId, name, price FROM toppings WHERE toppingId = ?";
        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, toppingId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {

                    Toppings topping = new Toppings();
                    topping.setToppingId(rs.getInt("toppingId"));
                    topping.setName(rs.getString("name"));
                    topping.setPrice(rs.getString("price"));
                    return topping;

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Pizza savePizzaToCart(Pizza pizza, HttpSession session) {
        List<Pizza> cart = (List<Pizza>) session.getAttribute("cart");
        if (cart == null) {
            cart = new ArrayList<>();
            session.setAttribute("cart", cart); //if no cart then create it which is tied to the session
        }

        pizza.setPizzaId(nextPizzaId++); //increments each pizza in the cart with its own unique id. Remember this also works because it is stateless.
        cart.add(pizza);
        return pizza;
    }

    public Pizza getPizzaWithToppings(int pizzaId) {
        Pizza pizza = null;
        String sql = """
            SELECT p.pizzaId, p.sizeId, p.crustTypeId,
                   s.name as sizeName, c.name as crustName,
                   t.toppingId, t.name as toppingName, t.price as toppingPrice
            FROM pizza p
            JOIN sizes s ON p.sizeId = s.sizeId
            JOIN crust_types c ON p.crustTypeId = c.crustTypeId
            LEFT JOIN pizza_toppings_map ptm ON p.pizzaId = ptm.pizzaId
            LEFT JOIN toppings t ON ptm.toppingId = t.toppingId
            WHERE p.pizzaId = ?
        """;

        try (Connection conn = dbConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, pizzaId);
            ResultSet rs = pstmt.executeQuery();

            boolean firstRow = true;
            while (rs.next()) {
                if (firstRow) {
                    pizza = new Pizza();
                    pizza.setPizzaId(rs.getInt("pizzaId"));
                    pizza.setSizeId(rs.getInt("sizeId"));
                    pizza.setCrustTypeId(rs.getInt("crustTypeId"));
                    pizza.setSizeName(rs.getString("sizeName"));
                    pizza.setCrustTypeName(rs.getString("crustName"));
                    firstRow = false;
                } //The pizza must only be set once hence the bool. Then we can loop through and get all of the toppings associated with the one pizza.

                if (rs.getInt("toppingId") != 0) {

                    Toppings topping = new Toppings();
                    topping.setToppingId(rs.getInt("toppingId"));
                    topping.setName(rs.getString("name"));
                    topping.setPrice(rs.getString("price"));
                    pizza.getToppings().add(topping);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pizza;
    }

    public double calculateCartTotal(List<Pizza> cart) {
        double total = 0.0;
        for (Pizza pizza : cart) {
            //calculate price for each pizza and its toppings
            double pizzaPrice = 10.0; //price for each size as a default.
            for (Toppings topping : pizza.getToppings()) {
                pizzaPrice += Double.parseDouble(topping.getPrice());
            }
            total += (pizzaPrice * pizza.getQuantity());
        }
        return total;
    }

    //for submitting order:
    public boolean savePizza(Pizza pizza) {
        String pizzaSql = """
            INSERT INTO pizza (sizeId, crustTypeId, price, orderId, isFinished, quantity)
            VALUES (?, ?, ?, ?, 0, ?)
            """;

        try (Connection conn = dbConnection.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement stmt = conn.prepareStatement(pizzaSql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, pizza.getSizeId());
                stmt.setInt(2, pizza.getCrustTypeId());
                stmt.setDouble(3, pizza.getTotalPrice());
                stmt.setInt(4, pizza.getOrderId());
                stmt.setInt(5, pizza.getQuantity());

                if (stmt.executeUpdate() > 0) {
                    try (ResultSet rs = stmt.getGeneratedKeys()) {
                        if (rs.next()) {
                            int pizzaId = rs.getInt(1);
                            pizza.setPizzaId(pizzaId);
                            savePizzaToppings(conn, pizza);
                            conn.commit();
                            return true;
                        }
                    }
                }
                conn.rollback();
                return false;
            }
        } catch (SQLException e) {

            return false;
        }
    }

    private void savePizzaToppings(Connection conn, Pizza pizza) throws SQLException { //gets the many to many relationship for each topping
        String sql = "INSERT INTO pizza_toppings_map (pizzaId, toppingId) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            for (Toppings topping : pizza.getToppings()) {
                stmt.setInt(1, pizza.getPizzaId());
                stmt.setInt(2, topping.getToppingId());
                stmt.addBatch();
            }
            stmt.executeBatch();
        }
    }

}
