/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import businessbeans.Customer;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Joel
 */
@Stateless
public class CustomerDAO {

    @Inject
    private DBConnection dbConnection;
    
    //pretty standard insert for customers.

    public Customer saveCustomer(Customer customer) {
        String sql = """
            INSERT INTO Customer (firstName, lastName, phoneNumber, email, 
                                houseNumber, street, province, postalCode)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getPhoneNumber());
            stmt.setString(4, customer.getEmail());
            stmt.setString(5, customer.getHouseNumber());
            stmt.setString(6, customer.getStreet());
            stmt.setString(7, customer.getProvince());
            stmt.setString(8, customer.getPostalCode());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows == 0) {
                return null;
            } //means it didn't work

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    customer.setCustomerId(generatedKeys.getInt(1));
                    return customer;
                } //So this is interesting. You need to bring back the generated keys because this method works in quick succession with the createorder function then with adding the pizza from session into the db. This is due to Order needing a customer id and you need to return a value in which case that is the customerId.
            }
        } catch (SQLException e) {
            
        }
        return null;
    }
}
