/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import businessbeans.CrustTypes;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Joel
 */
@Stateless
public class CrustTypesDAO {

    @Inject
    private DBConnection dbConnection;

    public List<CrustTypes> getAllCrustTypes() {
        List<CrustTypes> sizes = new ArrayList<>(); //gets all crusttypes
        String sql = "SELECT crustTypeId, name FROM crusttypes";

        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) { //loops through list and adds each crusttype to the arraylist.
                CrustTypes crustType = new CrustTypes();
                crustType.setCrustTypeId(rs.getInt("crustTypeId"));
                crustType.setName(rs.getString("name"));
                sizes.add(crustType);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sizes;
    }
}
