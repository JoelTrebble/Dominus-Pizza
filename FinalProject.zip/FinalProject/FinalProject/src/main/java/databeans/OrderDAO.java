/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package databeans;

import businessbeans.CrustTypes;
import businessbeans.Customer;
import businessbeans.Order;
import businessbeans.Pizza;
import businessbeans.Sizes;
import businessbeans.Toppings;
import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Joel
 */
@Stateless
public class OrderDAO {

    @Inject
    private DBConnection dbConnection;
    
    //technically the EJBs aren't read but I've done everything that I could to avoid the "new" keyword. With it being stateless, it would just erase the stateful list and would only read either the first or last value of whatever I was trying to loop through.

    @EJB
    private Order order;

    @EJB
    private Customer customer;

    @EJB
    private Pizza pizza;

    @EJB
    private Sizes size;

    @EJB
    private CrustTypes crustType;

    @EJB
    private Toppings topping;

   
    

    public Order createOrder(Order order) { //Pending is always the default value when an order is created.
        String sql = """
            INSERT INTO Orders (totalPrice, deliveryDateTime, placedDateTime, 
                              customerId, orderStatus, paymentStatus, orderMethod)
            VALUES (?, ?, NOW(), ?, 'Pending', ?, ?)
            """;
        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setDouble(1, order.getTotalPrice());
            stmt.setTimestamp(2, Timestamp.valueOf(order.getDeliveryDateTime()));
            stmt.setInt(3, order.getCustomerId());
            stmt.setString(4, order.getPaymentStatus());
            stmt.setString(5, order.getOrderMethod());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) { //generated key is needed as we need the value returned.
                    if (rs.next()) {
                        order.setOrderId(rs.getInt(1));
                        return order;
                    }
                }
            }
        } catch (SQLException e) {
            
        }
        return null;
    }

    public List<Order> getAllOrdersWithDetails(String statusFilter) { //This is the holy grail of all sql statements here. Pulls back everything from the employee dashboard. Probably could have done it with inner joins but I wanted to pull back "everything". plus this took me awhile to set up and I don't want to re-archtect it.
        Map<Integer, Order> orderMap = new HashMap<>(); //the list is stored in a hashmap. So the DESC in the orderby doesn't work (static key value map pairs) but I have a new method that circumvents that. 
//when this is called, orderstatus filters the orders that are done vs the ones that are pending. Hence the arg.
        String sql = """
   SELECT o.orderId, o.totalPrice, o.deliveryDateTime, o.placedDateTime, o.orderStatus, o.paymentStatus, o.orderMethod,
          c.customerId, c.firstName, c.lastName, c.phoneNumber, c.email, 
          c.houseNumber, c.street, c.province, c.postalCode,
          p.pizzaId, p.quantity,
          s.sizeId, s.name as sizeName,
          ct.crustTypeId, ct.name as crustTypeName,
          t.toppingId, t.name as toppingName, t.price as toppingPrice, t.isActive
   FROM Orders o
   JOIN Customer c ON o.customerId = c.customerId
   LEFT JOIN Pizza p ON o.orderId = p.orderId
   LEFT JOIN Sizes s ON p.sizeId = s.sizeId
   LEFT JOIN CrustTypes ct ON p.crustTypeId = ct.crustTypeId
   LEFT JOIN pizza_toppings_map ptm ON p.pizzaId = ptm.pizzaId
   LEFT JOIN Toppings t ON ptm.toppingId = t.toppingId
   WHERE o.orderStatus = ?
   ORDER BY o.orderId DESC, p.pizzaId, t.toppingId
   """;

        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

            if (statusFilter != null) {
                stmt.setString(1, statusFilter);
            } //set question mark to arg

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int orderId = rs.getInt("orderId");
                    Order order = orderMap.get(orderId);

                    if (order == null) {
                        
                        order = new Order();
                        
                        order.setTotalPrice(rs.getFloat("totalPrice"));
                        order.setOrderStatus(rs.getString("orderStatus"));
                        order.setDeliveryDateTime(rs.getTimestamp("deliveryDateTime").toLocalDateTime());
                        order.setPlacedDateTime(rs.getTimestamp("placedDateTime").toLocalDateTime());
                        order.setCustomerId(rs.getInt("customerId"));
                        order.setPaymentStatus(rs.getString("paymentStatus"));
                        order.setOrderMethod(rs.getString("orderMethod"));
                        order.setOrderId(orderId);

                        order.setOrderId(orderId);
                        
                        //if null then set the orderId. Tie that orderId with the value that the sql has been given

                        //So the order now has a customerId. That customerId now needs to have all its details filled out then tied back to the order
                        Customer customer = new Customer();
                        customer.setFirstName(rs.getString("firstName"));
                        customer.setLastName(rs.getString("lastName"));
                        customer.setPhoneNumber(rs.getString("phoneNumber"));
                        customer.setEmail(rs.getString("email"));
                        customer.setHouseNumber(rs.getString("houseNumber"));
                        customer.setStreet(rs.getString("street"));
                        customer.setProvince(rs.getString("province"));
                        customer.setPostalCode(rs.getString("postalCode"));

                        customer.setCustomerId(rs.getInt("customerId")); //sets the pk with the rest of the information
                        order.setCustomer(customer); //sets customer to the order.

                        orderMap.put(orderId, order); // Ties the key and value into the hashmap
                    }

                    int pizzaId = rs.getInt("pizzaId"); //gets the pizzaId associated.
                    if (pizzaId > 0) { //if there is a pizzaId, go to findorCreatePizza to add Pizza to the Pizza ArrayList that co-responds to each order instance.
                        Pizza pizza = findOrCreatePizza(order, pizzaId);

                        if (pizza.getPizzaId() == 0) { //only sets the properties of the pizza once we first create it.
                            pizza.setPizzaId(pizzaId);
                            pizza.setSizeId(rs.getInt("sizeId"));
                            pizza.setCrustTypeId(rs.getInt("crustTypeId"));
                            pizza.setQuantity(rs.getInt("quantity"));

                            
                            Sizes size = new Sizes(); //sets size that goes with each pizza.
                            size.setSizeId(rs.getInt("sizeId"));
                            size.setName(rs.getString("sizeName"));
                            pizza.setSize(size);

                            
                            CrustTypes crustType = new CrustTypes(); //ditto crust.
                            crustType.setCrustTypeId(rs.getInt("crustTypeId"));
                            crustType.setName(rs.getString("crustTypeName"));

                            pizza.setCrustType(crustType);

                            pizza.setOrderId(orderId); //ties that to the orderId.
                        }

                        int toppingId = rs.getInt("toppingId");
                        if (toppingId > 0) { //similar thing with toppings
                            

                            Toppings topping = new Toppings();
                            topping.setToppingId(rs.getInt("toppingId"));
                            topping.setName(rs.getString("toppingName"));
                            topping.setPrice(rs.getString("toppingPrice"));
                            topping.setIsActive(rs.getBoolean("isActive"));

                            pizza.getToppings().add(topping);
                        }
                    }
                }

                List<Order> sortedOrders = new ArrayList<>(orderMap.values()); //sort the hashmap. Probably not recommended but I needed this as I want the latest orders to appear at the top of the dashboard.
                sortedOrders.sort((o1, o2) -> Integer.compare(o2.getOrderId(), o1.getOrderId())); //if orderId is bigger than put it to the top. Binarry search. Prob not the most efficent but I didn't have a class in DSA lol

                return sortedOrders;
            }
        } catch (SQLException e) {
            
            return new ArrayList<>();
        }
    }

    private Pizza findOrCreatePizza(Order order, int pizzaId) {
        
        if (order.getPizzas() == null) {
            order.setPizzas(new ArrayList<>());
        } //if the list has no values, init a new arraylist for the pizzas to be added to each order.

        for (Pizza pizza : order.getPizzas()) { //if the pizza was already added to the list, just return it.
            if (pizza.getPizzaId() == pizzaId) {
                return pizza;
            }
        }

        Pizza pizza = new Pizza(); //else create a new instance of pizza. Then we'll fill the details of the pizza.
        order.getPizzas().add(pizza);
        return pizza;
    }

    public void updateOrderStatus(Integer orderId, String status) {
        try (Connection conn = dbConnection.getConnection(); PreparedStatement stmt = conn.prepareStatement(
                "UPDATE Orders SET orderStatus = ?, paymentStatus = 'Paid' WHERE orderId = ?")) {

            stmt.setString(1, status);
            stmt.setInt(2, orderId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            
        }
    }
     
}
