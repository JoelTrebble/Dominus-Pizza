/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import jakarta.ejb.Stateless;
import java.time.LocalDate;

/**
 *
 * @author Joel
 */
@Stateless
public class Toppings {
    
    // NOTE: These classes are messy because I originally tried to follow the UML diagram but then gave up and did my own thing.
    
    //no mods to this class and to the db. zero arg constructor for multiple injection types. All of my classes are EJBs which are stateless.

    private Integer toppingId;
    private String name;
    private String price;
    private LocalDate createDate;
    private Boolean isActive;

    private int pizzaId;

    public Toppings() {
    }

    public int getPizzaId() {
        return pizzaId;
    }

    public Integer getToppingId() {
        return toppingId;
    }

    public void setToppingId(Integer toppingId) {
        this.toppingId = toppingId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

}
