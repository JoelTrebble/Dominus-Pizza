/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import databeans.OrderDAO;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpSession;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.time.format.DateTimeFormatter;


/**
 *
 * @author Joel
 */
@Named("orderBL")
@Stateless
public class OrderBL {

    @Inject
    private OrderDAO orderDAO;
    
    @Inject
    private Order order;

    public Order createOrder(HttpSession session, int customerId, String paymentStatus, String orderMethod, String selectedTime) {
        float totalPrice = ((Double) session.getAttribute("cartTotal")).floatValue();
        if (totalPrice <= 0) {
            throw new IllegalArgumentException("Invalid cart total");
        }
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
        LocalTime time = LocalTime.parse(selectedTime, formatter);
        LocalDateTime deliveryDateTime = LocalDateTime.of(LocalDate.now(), time); //formats time for the db
        
        order.setTotalPrice(totalPrice); //sets attributes before creating an order
        order.setOrderStatus("Pending");
        order.setDeliveryDateTime(deliveryDateTime);
        order.setPlacedDateTime(LocalDateTime.now());
        order.setCustomerId(customerId);
        order.setPaymentStatus(paymentStatus);
        order.setOrderMethod(orderMethod);
        orderDAO.createOrder(order);
        return order;
    }

    public List<Order> getAllOrdersWithDetails(String statusFilter) {
        return orderDAO.getAllOrdersWithDetails(statusFilter);
    }

    public void updateOrderStatus(Integer orderId, String status) {
        orderDAO.updateOrderStatus(orderId, status);
    }

}
