/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import jakarta.ejb.Stateless;

/**
 *
 * @author Joel
 */
@Stateless
public class CrustTypes {
    
    //NOTE: These classes are messy because I originally tried to follow the UML diagram but then gave up and did my own thing.
    
    //no mods to this class and to the db. zero arg constructor for multiple injection types. All of my classes are EJBs which are stateless.

    private int crustTypeId;
    private String name;

    public CrustTypes() {
    }

    public int getCrustTypeId() {
        return crustTypeId;
    }

    public void setCrustTypeId(int crustTypeId) {
        this.crustTypeId = crustTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
