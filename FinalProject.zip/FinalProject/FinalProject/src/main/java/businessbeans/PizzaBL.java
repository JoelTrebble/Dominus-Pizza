/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import databeans.PizzaDAO;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Joel
 */
@Named("pizzaBL")
@Stateless
public class PizzaBL {

    @Inject
    private PizzaDAO pizzaDAO;

    @Inject
    private Pizza pizza;

    @Inject
    private Toppings topping;

    public Pizza addPizzaToCart(int sizeId, int crustTypeId, String[] selectedToppingIds,
            int quantity, HttpSession session) {
        Pizza pizza = new Pizza();

        //set size with name
        pizza.setSizeId(sizeId);
        pizza.setSizeName(pizzaDAO.getSizeName(sizeId));

        //set crust with name
        pizza.setCrustTypeId(crustTypeId);
        pizza.setCrustTypeName(pizzaDAO.getCrustTypeName(crustTypeId));

        //handle toppings with complete information
        List<Toppings> toppings = new ArrayList<>();
        if (selectedToppingIds != null) {
            for (String id : selectedToppingIds) {
                Toppings topping = pizzaDAO.getTopping(Integer.parseInt(id));
                if (topping != null) {
                    toppings.add(topping);
                }
            }
        }
        pizza.setToppings(toppings);

        
        pizza.setQuantity(quantity);

        // save to cart and return
        return pizzaDAO.savePizzaToCart(pizza, session);
    }

    public double getCartTotal(HttpSession session) {
        List<Pizza> cart = (List<Pizza>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            return 0.0;
        }
        double subtotal = pizzaDAO.calculateCartTotal(cart);

        //calculate tax and total
        double tax = subtotal * 0.15;
        double totalWithTax = subtotal + tax;

        //Store all values in session
        session.setAttribute("cartSubtotal", subtotal);
        session.setAttribute("cartTax", tax);
        session.setAttribute("cartTotal", totalWithTax);

        return totalWithTax;
    }

    public boolean savePizzasFromCart(HttpSession session, int orderId) {
        List<Pizza> cart = (List<Pizza>) session.getAttribute("cart");
        boolean success = true;
        for (Pizza pizza : cart) {
            pizza.setOrderId(orderId);
            if (!pizzaDAO.savePizza(pizza)) {
                success = false;
                break;
            }
        }
        return success;
    }

}
