/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import databeans.EmployeeDAO;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;

/**
 *
 * @author Joel
 */
@Named("employeeBL")
@Stateless
public class EmployeeBL {

    @Inject
    private EmployeeDAO employeeDAO;

    public Employee login(String username, String password) {
        return employeeDAO.validateLogin(username, password);
    }

}
