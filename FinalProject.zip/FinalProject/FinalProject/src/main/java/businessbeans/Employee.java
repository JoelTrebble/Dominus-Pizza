/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import jakarta.ejb.Stateless;


/**
 *
 * @author Joel
 */
@Stateless
public class Employee  {
    
     //NOTE: These classes are messy because I originally tried to follow the UML diagram but then gave up and did my own thing.
    
    
    //no mods to this class and to the db. zero arg constructor for multiple injection types. All of my classes are EJBs which are stateless.

    private String userName;
    private String password;

    public Employee() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
