/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import databeans.ToppingsDAO;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.List;

/**
 *
 * @author Joel
 */
@Named("toppingBL")
@Stateless
public class ToppingsBL {

    @Inject
    private ToppingsDAO toppingsDAO;

    public List<Toppings> getAllToppings() {
        return toppingsDAO.getAllToppings();
    }

    public List<Toppings> getAllToppingsCustomer() {
        return toppingsDAO.getAllToppingsCustomer();
    }

    public void updateToppingStatus(Integer toppingId, boolean isActive) {
        toppingsDAO.updateToppingStatus(toppingId, isActive);

    }

    public void addTopping(String name, String price) {
        toppingsDAO.addTopping(name, price);
    }

}
