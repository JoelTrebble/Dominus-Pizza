/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import jakarta.ejb.Stateless;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author Joel
 */
@Stateless
public class Order  {
    
     //NOTE: These classes are messy because I originally tried to follow the UML diagram but then gave up and did my own thing.
    
    
    //Mods to this class. zero arg constructor for multiple injection types. All of my classes are EJBs which are stateless.

    private float totalPrice;
    private String orderStatus;
    private LocalDateTime deliveryDateTime;
    private LocalDateTime placedDateTime;
    private int customerId;
    private int orderId;
    private String paymentStatus; //modified db so that I could pull back the payment status in the employee dashboard.
    private String orderMethod; //modified db so that I could pull back the order status in the employee dashboard.

    //These two are needed for when we pull everything back from the DB into the employee dashboard.
    private List<Pizza> pizzas;
    private Customer customer;

    public Order() {
    }

    public List<Pizza> getPizzas() {
        return pizzas;
    }

    public void setPizzas(List<Pizza> pizzas) {
        this.pizzas = pizzas;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getOrderMethod() {
        return orderMethod;
    }

    public void setOrderMethod(String orderMethod) {
        this.orderMethod = orderMethod;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public LocalDateTime getDeliveryDateTime() {
        return deliveryDateTime;
    }

    public void setDeliveryDateTime(LocalDateTime deliveryDateTime) {
        this.deliveryDateTime = deliveryDateTime;
    }

    public LocalDateTime getPlacedDateTime() {
        return placedDateTime;
    }

    public void setPlacedDateTime(LocalDateTime placeDateTime) {
        this.placedDateTime = placeDateTime;
    }

}
