/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import jakarta.ejb.Stateless;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Joel
 */
@Stateless
public class Pizza {
    
    //NOW: using double isn't recommended for currency but with my stress testing, the precision that double has for the calculations that I am doing are good enough.
    
    //NOTE: These classes are messy because I originally tried to follow the UML diagram but then gave up and did my own thing.
    
    //Mods to this class. zero arg constructor for multiple injection types. All of my classes are EJBs which are stateless.

    private int pizzaId;
    private int sizeId;
    private int crustTypeId;
    private String sizeName;
    private String crustTypeName;
    private List<Toppings> toppings;
    private double totalPrice;

    private int quantity; //added to the db.

    private int orderId;

    private Sizes size;
    private CrustTypes crustType;

    public Pizza() {
        this.toppings = new ArrayList<>();
    }

    public Sizes getSize() {
        return size;
    }

    public CrustTypes getCrustType() {
        return crustType;
    }

    public void setSize(Sizes size) {
        this.size = size;
    }

    public void setCrustType(CrustTypes crustType) {
        this.crustType = crustType;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getPizzaId() {
        return pizzaId;
    }

    public void setPizzaId(int pizzaId) {
        this.pizzaId = pizzaId;
    }

    public int getSizeId() {
        return sizeId;
    }

    public void setSizeId(int sizeId) {
        this.sizeId = sizeId;
    }

    public int getCrustTypeId() {
        return crustTypeId;
    }

    public void setCrustTypeId(int crustTypeId) {
        this.crustTypeId = crustTypeId;
    }

    public String getSizeName() {
        return sizeName;
    }

    public void setSizeName(String sizeName) {
        this.sizeName = sizeName;
    }

    public String getCrustTypeName() {
        return crustTypeName;
    }

    public void setCrustTypeName(String crustTypeName) {
        this.crustTypeName = crustTypeName;
    }

    public List<Toppings> getToppings() {
        return toppings;
    }

    public void setToppings(List<Toppings> toppings) {
        this.toppings = toppings;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

}
