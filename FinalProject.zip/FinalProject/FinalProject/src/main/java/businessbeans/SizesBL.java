/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import databeans.SizesDAO;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.List;

/**
 *
 * @author Joel
 */
@Named("sizesBL")
@Stateless
public class SizesBL {
    @Inject
    private SizesDAO sizesDAO;
    
    public List<Sizes> getAllSizes() {
        return sizesDAO.getAllSizes();
    }
}
