/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessbeans;

import databeans.CustomerDAO;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;

/**
 *
 * @author Joel
 */
@Named("customerBL")
@Stateless
public class CustomerBL {
    
    @Inject
    private CustomerDAO customerDAO;
    
    @Inject
    private Customer customer;
    
    public Customer saveCustomer(HttpServletRequest request) { //prepares the dao to save customer
        customer.setFirstName(request.getParameter("firstName"));
        customer.setLastName(request.getParameter("lastName"));
        customer.setPhoneNumber(request.getParameter("phoneNumber"));
        customer.setEmail(request.getParameter("email"));
        customer.setHouseNumber(request.getParameter("houseNumber"));
        customer.setStreet(request.getParameter("street"));
        customer.setProvince(request.getParameter("province"));
        customer.setPostalCode(request.getParameter("postalCode"));
        return customerDAO.saveCustomer(customer);
    }
    
   

}
