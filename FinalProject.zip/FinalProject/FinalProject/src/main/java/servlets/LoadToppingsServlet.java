/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.Order;
import businessbeans.OrderBL;
import businessbeans.Toppings;
import businessbeans.ToppingsBL;
import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;

/**
 *
 * @author Joel
 */
public class LoadToppingsServlet extends HttpServlet {

    @Inject
    private ToppingsBL toppingsBL;

    @Inject
    private OrderBL ordersBL;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        if (session.getAttribute("employee") == null) {
            response.sendRedirect("EmployeeLogin.jsp");
            return;
        }

        try {
            List<Toppings> toppings = toppingsBL.getAllToppings();
            String orderFilter = request.getParameter("orderFilter");
            if (orderFilter == null) {
                orderFilter = "PENDING"; //needed for initial load
            }
            List<Order> orders = ordersBL.getAllOrdersWithDetails(orderFilter);

            request.setAttribute("toppings", toppings);
            request.setAttribute("orders", orders);
            

            request.getRequestDispatcher("/EmployeeDashboard.jsp").forward(request, response); //I'm not happy with this as the URL still shows the Servlet but I am leaving it here as it works.
            //Since this is also the employee side of the application. I'm not too worried about a minor thing like this.
            

        } catch (Exception e) {
            e.printStackTrace();
            
        }
    }

}
