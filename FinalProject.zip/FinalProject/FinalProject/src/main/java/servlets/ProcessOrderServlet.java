/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.Customer;
import businessbeans.CustomerBL;
import businessbeans.Order;
import businessbeans.OrderBL;
import businessbeans.PizzaBL;
import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Joel
 */
public class ProcessOrderServlet extends HttpServlet {

    @Inject
    private PizzaBL pizzaBL;
    @Inject
    private OrderBL orderBL;
    @Inject
    private CustomerBL customerBL;

    //This is a bit messy but I couldn't parse it client side with js on the form so I had to do it with the servlet
    //might be some duplication of comments as I'm writing these somewhat disjointedly but the way the DB works is: Customer must be created first because each order is tied to a customer and then each pizza is tied to an order.
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();

        String paymentStatus = request.getParameter("paymentStatus");
        String orderMethod = request.getParameter("orderMethod");

        String selectedTime;
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
        if (orderMethod.equals("Delivery")) {
            //calculate delivery time as current time + 30 minutes from button submit. Screw whatever we gave as an estimate as customers could spend over 30 minutes debating on whether this is the right pizza or not.

            selectedTime = now.plusMinutes(30).format(formatter);
        } else {
            //parse the selected pickup time
            String pickupTimeStr = request.getParameter("pickupTime");
            LocalTime selectedPickupTime = LocalTime.parse(pickupTimeStr, formatter);
            LocalDateTime selectedDateTime = LocalDateTime.of(LocalDate.now(), selectedPickupTime);

            //if selected time is less than 30 minutes from now, default to now + 30
            if (selectedDateTime.isBefore(now.plusMinutes(30))) {
                selectedTime = now.plusMinutes(30).format(formatter);
            } else {
                selectedTime = pickupTimeStr;
            }
        }

        Customer customer = customerBL.saveCustomer(request);
        if (customer == null) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, //sends to console server. Error 500.
                    "Failed to save customer information"); //returns if there is a failure any way through the chain.
            return;
        }

        Order order = orderBL.createOrder(session, customer.getCustomerId(), paymentStatus, orderMethod, selectedTime);
        if (order == null) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Failed to create order");
            return;
        }

        if (!pizzaBL.savePizzasFromCart(session, order.getOrderId())) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Failed to save pizza information");
            return;
        }

        session.removeAttribute("cart");
        response.sendRedirect("Order.jsp");
    }

}
