/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.Employee;
import businessbeans.EmployeeBL;
import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author Joel
 */
public class LoginServlet extends HttpServlet {

    @Inject
    private EmployeeBL employeeBL;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //similar to the proc in the OG sprints for php for plain text login. Since there is only one admin/user, there is no iteration as of yet.
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Employee employee = employeeBL.login(username, password);
            HttpSession session = request.getSession();
            session.setAttribute("employee", employee);

            response.sendRedirect(request.getContextPath() + "/LoadToppingsServlet");

        } catch (Exception e) {
            request.getSession().setAttribute("errorMessage", "Invalid username or password");
            response.sendRedirect("EmployeeLogin.jsp");
        }
    }

}
