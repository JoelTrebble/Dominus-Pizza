/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.Pizza;
import businessbeans.PizzaBL;
import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;

/**
 *
 * @author Joel
 */
public class RemoveFromCartServlet extends HttpServlet {
    @Inject
    private PizzaBL pizzaBL;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            int pizzaId = Integer.parseInt(request.getParameter("pizzaId"));
            
            HttpSession session = request.getSession(); //gets session
            List<Pizza> cart = (List<Pizza>) session.getAttribute("cart"); //gets list of pizzas from the cart from sessoin
            
            if (cart != null) {
                cart.removeIf(pizza -> pizza.getPizzaId() == pizzaId);
                session.setAttribute("cart", cart); //update the session attribute
                //recalculate totals after removing pizza
                pizzaBL.getCartTotal(session);
            }
            
            response.sendRedirect(request.getContextPath() + "/Order.jsp");
        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }
}

