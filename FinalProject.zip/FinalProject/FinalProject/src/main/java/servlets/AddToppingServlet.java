/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.ToppingsBL;
import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author Joel
 */
public class AddToppingServlet extends HttpServlet {

    @Inject
    private ToppingsBL toppingsBL;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        //must be logged in to view this page.
        if (session.getAttribute("employee") == null) {
            response.sendRedirect("EmployeeLogin.jsp");
            return;
        }

        try {
            String name = request.getParameter("name");
            String price = request.getParameter("price");
            //if name and price is not empty and it's not just spacebar then addTopping to the DB
            if (name != null && !name.trim().isEmpty()
                    && price != null && !price.trim().isEmpty()) {

                toppingsBL.addTopping(name, price);

                //LoadTopping redirect as the central servlet powering the employee dashboard.
                response.sendRedirect(request.getContextPath() + "/LoadToppingsServlet");
            } else {
                throw new ServletException("Name and price are required");
            }

        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
