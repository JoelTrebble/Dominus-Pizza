/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.CrustTypes;
import businessbeans.CrustTypesBL;
import businessbeans.Sizes;
import businessbeans.SizesBL;
import businessbeans.Toppings;
import businessbeans.ToppingsBL;
import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;

/**
 *
 * @author Joel
 */
public class StartServlet extends HttpServlet {

    @Inject
    private ToppingsBL toppingsBL;

    @Inject
    private SizesBL sizesBL;

    @Inject
    private CrustTypesBL crusttypesBL;
//load BLs at startup to then use its business logic to bring back all available toppings, sizes and crusttypes.
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Toppings> toppings = toppingsBL.getAllToppingsCustomer();
        List<Sizes> sizes = sizesBL.getAllSizes();
        List<CrustTypes> crusttypes = crusttypesBL.getAllCrustTypes();

        request.getSession().setAttribute("crusttypes", crusttypes);
        request.getSession().setAttribute("sizes", sizes);
        request.getSession().setAttribute("toppings", toppings);
        response.sendRedirect(request.getContextPath() + "/Order.jsp");

    }

}
