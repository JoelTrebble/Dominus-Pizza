/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;


import businessbeans.PizzaBL;

import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


/**
 *
 * @author Joel
 */
public class AddToCartServlet extends HttpServlet {

    
    @Inject
    private PizzaBL pizzaBL;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            //gets parameters
            int sizeId = Integer.parseInt(request.getParameter("size"));
            int crustTypeId = Integer.parseInt(request.getParameter("crustType"));
            String[] selectedToppingIds = request.getParameterValues("selectedToppings");
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            
            //adds pizza to session
            HttpSession session = request.getSession();
            pizzaBL.addPizzaToCart(sizeId, crustTypeId, selectedToppingIds, quantity, session);
            
            //calculate and get total
            pizzaBL.getCartTotal(session);
            
            response.sendRedirect(request.getContextPath() + "/Order.jsp");
            
        } catch (Exception e) {
            
            e.printStackTrace();
            
        }
    }
}
