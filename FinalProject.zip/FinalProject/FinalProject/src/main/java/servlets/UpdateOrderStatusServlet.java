/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.OrderBL;
import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author Joel
 */
public class UpdateOrderStatusServlet extends HttpServlet {

    @Inject
    private OrderBL orderBL;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        if (session.getAttribute("employee") == null) {
            response.sendRedirect("EmployeeLogin.jsp");
            return;
        }
        //again employee must be logged in.

        try {
            String orderIdStr = request.getParameter("orderId");

            if (orderIdStr != null) {
                Integer orderId = Integer.parseInt(orderIdStr);
                orderBL.updateOrderStatus(orderId, "FILLED");

                
                response.sendRedirect(request.getContextPath() + "/LoadToppingsServlet");
            }

        } catch (Exception e) {
            e.printStackTrace();
            
        }
    }
}
