/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import businessbeans.ToppingsBL;

import jakarta.inject.Inject;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author Joel
 */
public class UpdateToppingStatusServlet extends HttpServlet {
    @Inject
    private ToppingsBL toppingsBL;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        
        if (session.getAttribute("employee") == null) {
            response.sendRedirect("EmployeeLogin.jsp");
            return;
        }
        //again employee must be in session
        
        try {
            String toppingIdStr = request.getParameter("toppingId");
            String statusStr = request.getParameter("status");
            
            if (toppingIdStr != null && statusStr != null) { //if both are not null then update topping status
                Integer toppingId = Integer.parseInt(toppingIdStr);
                boolean isActive = Boolean.parseBoolean(statusStr);
                
                toppingsBL.updateToppingStatus(toppingId, isActive);
                
                response.sendRedirect(request.getContextPath() + "/LoadToppingsServlet"); //central loadtoppingsservlet which redirects to there.
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            
        }
    }
}